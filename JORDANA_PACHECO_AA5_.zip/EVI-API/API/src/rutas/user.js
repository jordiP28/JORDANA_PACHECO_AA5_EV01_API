const express = require("express");
const userSchema = require("../modelos/user")

const router = express.Router();

// Crear usuario
router.post("/users", (req, res) => {
    const user = new userSchema(req.body); 

    user
        .save()
        .then((data) => {
        res.status(201).json({ mensaje: "Usuario registrado exitosamente", data });
        })
        .catch((error) => res.status(400).json({ message: error.message })); 
});

// Obetener todos los usuarioas
router.get("/users", (req, res) => {
    userSchema
     .find()
     .then((data) => {
        res.status(201).json({ mensaje: "Lista de usuarios", data });
        })
        .catch((error) => res.status(400).json({ message: error.message })); 
});
// Encontrar usuario
router.get("/users/:id", (req, res) => {
    const { id } = req.params;
    userSchema
     .findById(id)
     .then((data) => res.json(data))
     .catch((error)=> res.json({ message : error }));
 });

 // Actualizar usuario
 router.put("/users/:id", (req, res) => {
    const { id } = req.params;
    const { Nombre, Apellidos, Email } = req.body;
    userSchema
     .updateOne({_id: id }, { $set: {Nombre, Apellidos, Email}})
     .then((data) => {
        res.status(201).json({ mensaje: "Usuario Actualizado Exitosamente", data });
        })
        .catch((error) => res.status(400).json({ message: error.message })); 
});

 // Eliminar usuario
 router.delete("/users/:id", (req, res) => {
    const { id } = req.params;
    userSchema
      .deleteOne({ _id: id })
      .then((data) => {
        res.status(201).json({ mensaje: "Usuario Eliminado Exitosamente", data });
        })
        .catch((error) => res.status(400).json({ message: error.message })); 
});
  


module.exports = router;