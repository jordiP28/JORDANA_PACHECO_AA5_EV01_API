const mongoose = require("mongoose");

const userSchema = mongoose.Schema({
  Nombre:{
    type: String,
    required: true
 },
  Apellidos:{
    type:String,
    required:true
  },
  Email:{
    type:String,
    required:true
  }
});

module.exports = mongoose.model('user', userSchema);